"""
-------------------------------------------------------
Assignment 1, Task 8
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 7, 2026
-------------------------------------------------------
"""

#Imports
from functions import matrixes_multiply

matrix_a=[
    [1,2,3],
    [7,8,9],
    [4,5,6]]

matrix_b=[
    [2,1],
    [6,7],
    [4,5]]

product=matrixes_multiply(matrix_a,matrix_b)

print(product)


