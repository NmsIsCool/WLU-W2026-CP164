"""
-------------------------------------------------------
Assignment 1, Task 7
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 7, 2026
-------------------------------------------------------
"""

#Imports
from functions import is_palindrome

string=input("Enter a string: ")
palindrome=is_palindrome(string)

print(f"Is palindrome? -> {palindrome}")

