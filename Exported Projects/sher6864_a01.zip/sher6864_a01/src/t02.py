"""
-------------------------------------------------------
Assignment 1, Task 2
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 6, 2026
-------------------------------------------------------
"""

#Imports
from functions import list_subtraction

minuend=[1,2,3,4,5,6,7,8,9,10,14,18,22,7,6,99]
subtrahend=[7,6,99,22]

print(f"Minuend: {minuend}")
print(f"Subtrahend: {subtrahend}")

list_subtraction(minuend, subtrahend)

print(f"Result: {minuend}")


