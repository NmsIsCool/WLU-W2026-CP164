"""
-------------------------------------------------------
Assignment 1, Task 3
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 7, 2026
-------------------------------------------------------
"""

#Imports
from functions import dsmvwl

string=input("Enter a string: ")
string.strip()

output=dsmvwl(string)
print("Dsmvwld string:",output)

