"""
-------------------------------------------------------
Assignment 1, Task 1
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 6, 2026
-------------------------------------------------------
"""

#Imports
from functions import clean_list

nums=[1,3,5,7,9,2,4,6,8,1,5,9,4,8,0]

print(f"Original list: {nums}")

clean_list(nums)

print(f"Clean List: {nums}")


