"""
-------------------------------------------------------
Food class utility functions.
-------------------------------------------------------
Author:  David Brown
ID:      123456789
Email:   dbrown@wlu.ca
__updated__ = "2023-05-15"
-------------------------------------------------------
"""
from Food import Food


def get_food():
    """
    -------------------------------------------------------
    Creates a Food object by requesting data from a user.
    Use: source = get_food()
    -------------------------------------------------------
    Returns:
        food - a completed food object (Food).
    -------------------------------------------------------
    """

    # Your code here
    name=input("Name: ") 
    
    print("Origin")
    print(Food.origins())
    origin=int(input(":"))
    
    is_vegetarian=False
    is_vegetarian_string=input("Vegetarian (Y/N): ")
    if(is_vegetarian_string=="True"):
        is_vegetarian=True
    else:
        is_vegetarian=False
    
    calories=int(input("Calories: "))
    
    food=Food(name,origin,is_vegetarian,calories)
    return food


def read_food(line):
    """
    -------------------------------------------------------
    Creates and returns a Food object from a line of string data.
    Use: source = read_food(line)
    -------------------------------------------------------
    Parameters:
        line - a vertical bar-delimited line of food data in the format
          name|origin|is_vegetarian|calories (str)
    Returns:
        food - contains the data from line (Food)
    -------------------------------------------------------
    """

    # Your code here
    elements=line.split("|")
    name=elements[0]
    origin=int(elements[1])
    
    is_veg_string=elements[2]
    if(is_veg_string=="True"):
        is_veg=True
    else:
        is_veg=False
    
    calories=int(elements[3])
    
    food=Food(name,origin,is_veg,calories)

    return food


def read_foods(file_variable):
    """
    -------------------------------------------------------
    Reads a file of food strings into a list of Food objects.
    Use: foods = read_foods(file_variable)
    -------------------------------------------------------
    Parameters:
        file_variable - an open file of food data (file)
    Returns:
        foods - a list of food objects (list of Food)
    -------------------------------------------------------
    """

    # Your code here
    foods=[]
    
    line=file_variable.readline().strip()
    while line:
        food=read_food(line)
        foods.append(food)
        line=file_variable.readline()
        
    return foods


def write_foods(file_variable, foods):
    """
    -------------------------------------------------------
    Writes a list of Food objects to a file.
    file_variable contains the objects in foods as strings in the format
          name|origin|is_vegetarian|calories
    foods is unchanged.
    Use: write_foods(file_variable, foods)
    -------------------------------------------------------
    Parameters:
        file_variable - an open file of food data (file variable)
        foods - a list of Food objects (list of Food)
    Returns:
        None
    -------------------------------------------------------
    """

    # Your code here
    for i in range (len(foods)):
        string=f"{foods[i].name}|{foods[i].origin}|{foods[i].is_vegetarian}|{foods[i].calories}\n"
        file_variable.write(string)

    return


def get_vegetarian(foods):
    """
    -------------------------------------------------------
    Creates a list of vegetarian Food objects.
    foods is unchanged.
    Use: v_foods = get_vegetarian(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        veggies - Food objects from foods that are vegetarian (list of Food)
    -------------------------------------------------------
    """

    # Your code here
    veggies=[]
    
    for i in range (len(foods)):
        if(foods[i].is_vegetarian):
            veggies.append(foods[i])
            

    return veggies


def by_origin(foods, origin):
    """
    -------------------------------------------------------
    Creates a list of Food objects by origin.
    foods is unchanged.
    Use: o_foods = by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - a food origin (int)
    Returns:
        origins - Food objects from foods that are of a particular origin (list of Food)
    -------------------------------------------------------
    """
    assert origin in range(len(Food.ORIGIN)), "Origin must be within origins list"


    # Your code here
    origins=[]
    
    for i in range (len(foods)):
        if foods[i].origin == origin:
            origins.append(foods[i])
            
    return origins


def average_calories(foods):
    """
    -------------------------------------------------------
    Determines the average calories in a list of Foods objects.
    foods is unchanged.
    Use: avg = average_calories(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        avg - average calories in all Food objects of foods (int)
    -------------------------------------------------------
    """

    # Your code here
    total=0
    for i in range(len(foods)):
        total+=(foods[i].calories)
    avg=total/len(foods)

    return avg


def calories_by_origin(foods, origin):
    """
    -------------------------------------------------------
    Determines the average calories in a list of Foods objects.
    foods is unchanged.
    Use: by_origin = calories_by_origin(foods, origin)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the Food objects to find (int)
    Returns:
        avg - average calories for all Foods of the requested origin (int)
    -------------------------------------------------------
    """
    assert origin in range(len(Food.ORIGIN)), "Origin must be within origins list"

    # Your code here
    foods_of_origin=by_origin(foods, origin)
    
    avg=average_calories(foods_of_origin)

    return avg


def food_table(foods):
    """
    -------------------------------------------------------
    Prints a formatted table of Food objects, sorted by name.
    foods is unchanged.
    Use: food_table(foods)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
    Returns:
        None
    -------------------------------------------------------
    """

    # Your code here
    temp_foods=sorted(foods)
    
    #One Time Run Behavior
    print("Food                                Origin       Vegetarian Calories")
    print("----------------------------------- ------------ ---------- --------")
    
    #Iterate <foods> and print attributes
    for i in range(len(temp_foods)):
        print(f"{temp_foods[i].name:<36}{Food.ORIGIN[temp_foods[i].origin]:<13}{temp_foods[i].is_vegetarian!s:>10}{temp_foods[i].calories:>9}")
    return


def food_search(foods, origin, max_cals, is_veg):
    """
    -------------------------------------------------------
    Searches for Food objects that fit certain conditions.
    foods is unchanged.
    Use: results = food_search(foods, origin, max_cals, is_veg)
    -------------------------------------------------------
    Parameters:
        foods - a list of Food objects (list of Food)
        origin - the origin of the food; if -1, accept any origin (int)
        max_cals - the maximum calories for the food; if 0, accept any calories value (int)
        is_veg - whether the food is vegetarian or not; if False accept any food (boolean)
    Returns:
        result - a list of foods that fit the conditions (list of Food)
            foods parameter must be unchanged
    -------------------------------------------------------
    """
    assert origin in range(-1, len(Food.ORIGIN)), "Origin must be within origins list, or -1"

    # Your code here
    result=[]
    
    for i in range (len(foods)):
        if(foods[i].origin == origin or origin == -1):
            if(foods[i].calories<= max_cals or max_cals == 0):
                if(not bool(is_veg)) or bool(foods[i].is_vegetarian):
                    result.append(foods[i])
    
    result.sort()
    
    return result
