"""
-------------------------------------------------------
Lab 3, Task 1
-------------------------------------------------------
Author:  Jack Sherwood
ID:             169116864
Email:        sher6864@mylaurier.ca
__updated__ = '2026-01-20'
-------------------------------------------------------
"""

from Queue_array import Queue

queue=Queue()

value=input("Enter something to insert into the queue: ")
queue.insert(value)
print("Value Inserted! (I promise)")

