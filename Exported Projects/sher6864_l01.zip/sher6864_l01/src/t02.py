"""
-------------------------------------------------------
Lab 1, Task 2
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 8, 2026
-------------------------------------------------------
"""

#Imports

from Food import Food

butter_chicken=Food("Butter Chicken",2,False,490)
butter_chicken_string=str(butter_chicken)
print(butter_chicken_string)

