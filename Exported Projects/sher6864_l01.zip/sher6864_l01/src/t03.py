"""
-------------------------------------------------------
Lab 1, Task 3
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 8, 2026
-------------------------------------------------------
"""

#Imports
from Food_utilities import get_food

food=get_food()
print(food)
