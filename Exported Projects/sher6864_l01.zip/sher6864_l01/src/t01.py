"""
-------------------------------------------------------
Lab 1, Task 1
-------------------------------------------------------
Author:  Jack Sherwood
ID:             1691168645
Email:        sher6864@mylaurier.ca
__updated__ = Jan 8, 2026
-------------------------------------------------------
"""

#Imports
from Food import Food

origins_list=Food.origins()
print(origins_list)



